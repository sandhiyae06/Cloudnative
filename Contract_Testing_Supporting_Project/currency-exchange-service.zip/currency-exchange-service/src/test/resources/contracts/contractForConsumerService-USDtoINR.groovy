import org.springframework.cloud.contract.spec.Contract
    Contract.make {
        description "should return Conversion Multiple of Currency"
        request{
            method GET()
            url("/currency-exchange/from/{from}/to/{to}") {
                queryParameters {
                    parameter 'from' : 'USD'
                    parameter 'to' : 'INR'
                }
            }
        }
        response {
            status 200
            headers {
            contentType applicationJson()
                }
            body(
                id: 10001,
                from: 'USD',
                to: 'INR',
                conversionMultiple: 75,
                port: 8000
            )
        }
    }
import org.springframework.cloud.contract.spec.Contract
    Contract.make {
        description "should return Conversion Multiple of Currency"
        request{
            method GET()
            url("/currency-exchange/from/{from}/to/{to}") {
                queryParameters {
                    parameter 'from' : 'EUR'
                    parameter 'to' : 'INR'
                }
            }
        }
        response {
            status 200
            headers {
            contentType applicationJson()
                }
            body(
                id: 10002,
                from: 'EUR',
                to: 'INR',
                conversionMultiple: 84,
                port: 8000
            )
        }
    }
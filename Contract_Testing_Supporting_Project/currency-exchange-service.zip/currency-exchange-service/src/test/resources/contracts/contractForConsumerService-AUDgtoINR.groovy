import org.springframework.cloud.contract.spec.Contract
    Contract.make {
        description "should return Conversion Multiple of Currency"
        request{
            method GET()
            url("/currency-exchange/from/{from}/to/{to}") {
                queryParameters {
                    parameter 'from' : 'AUD'
                    parameter 'to' : 'INR'
                }
            }
        }
        response {
            status 200
            headers {
            contentType applicationJson()
                }
            body(
                id: 10003,
                from: 'AUD',
                to: 'INR',
                conversionMultiple: 52,
                port: 8000
            )
        }
    }
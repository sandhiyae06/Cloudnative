/**
 * 
 */
package com.cts.microservices.currencyexchangeservice;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author 616814
 *
 */
@Entity
@ApiModel(description = "All details about the ExchangeValue")
public class ExchangeValue {
	
	@Id
	private Long id;
	
	@Size(min = 3, message = "from should have atleast 3 characters")
	@ApiModelProperty(notes = "from should have atleast 3 characters")
	@Column(name="currency_from")
	private String from;
	
	@Size(min = 3, message = "to should have atleast 3 characters")
	@ApiModelProperty(notes = "to should have atleast 3 characters")
	@Column(name="currency_to")
	private String to;
	
	@Positive(message = "conversionMultiple should have valid multiplier")
	@ApiModelProperty(notes = "conversionMultiple should have valid multiplier")
	private BigDecimal conversionMultiple;
	
	@Positive(message = "port should not be empty")
	@ApiModelProperty(notes = "port should not be empty")
	private int port;
	
	public ExchangeValue() {
		
	}
	
	public ExchangeValue(Long id, String from, String to, BigDecimal conversionMultiple) {
		super();
		this.id = id;
		this.from = from;
		this.to = to;
		this.conversionMultiple = conversionMultiple;
	}	
	
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public Long getId() {
		return id;
	}

	public String getFrom() {
		return from;
	}

	public String getTo() {
		return to;
	}

	public BigDecimal getConversionMultiple() {
		return conversionMultiple;
	}

}

package com.ContractTesting;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.contract.stubrunner.spring.StubRunnerProperties;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.client.RestTemplate;

import com.ContractTesting.ConversionService.CurrencyConversionBean;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
@AutoConfigureStubRunner(stubsMode = StubRunnerProperties.StubsMode.LOCAL, ids = "com.cts.microservices:currency-exchange-service:+:stubs:8091")
public class CurrencyConversionServiceApplicationTests extends BaseTest{

	@Autowired
	private MockMvc mockMvc;
	public static ExtentTest test;
	public static ExtentReports report;
	static String response;
	@Autowired
	RestTemplate restTemplate;
	@BeforeClass
	public static void startTest()
	{
	report = new ExtentReports("C:\\Users\\316444\\OneDrive - Cognizant\\Desktop\\API Sample FW\\New folder\\currency-conversion-service\\ExtentReport\\ExtentReportResults.html",true);
	}
	@Test
	@DisplayName("USD to INR Convertor")
	public void given_WhenConvertingFromUSDtoINR_ThenReturn() throws Exception {
		test = report.startTest("USD to INR Convertor Fail");
		response = "{\"id\": 10001,\"from\": \"USD\",\"to\": \"INR\",\"conversionMultiple\": 75.00,\"quantity\": 100,\"totalCalculatedAmount\": 7500.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/USD/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		//.andExpect(status().isOk())
		//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
	}
	@Test
	@DisplayName("USD to INR Convertor")
	public void given_WhenConvertingFromUSDtoINR_ThenReturn2() throws Exception {
		test = report.startTest("USD to INR Convertor Fail");
		String response1 = "{\"id\": 10001,\"from\": \"USD\",\"to\": \"INR\",\"conversionMultiple\": 75.00,\"quantity\": 100,\"totalCalculatedAmount\": 7500.00,\"port\":8000}";
		/*MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/USD/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		//.andExpect(status().isOk())
		//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();*/
		Map<String, String> uriVaribales = new HashMap<String, String>();
		uriVaribales.put("from", "USD");
		uriVaribales.put("to", "INR");
		ResponseEntity<CurrencyConversionBean> responseEntity = restTemplate.getForEntity(
				"http://localhost:8000/currency-exchange/from/USD/to/INR", CurrencyConversionBean.class,
				uriVaribales);
		
		CurrencyConversionBean response = responseEntity.getBody();
		
		String actualResponse="{\"id\": "+response.getId()+",\"from\": \""+uriVaribales.get("from")+"\",\"to\": \""+uriVaribales.get("from")+"\",\"conversionMultiple\": "+response.getConversionMultiple().intValueExact()+",\"quantity\": 100,"
				+ "\"totalCalculatedAmount\": "+100*(response.getConversionMultiple().intValueExact())+",\"port\":"+response.getPort()+"}";
		validateResponse (actualResponse,response1);
	}
	/*@Test
	@DisplayName("USD to INR Convertor")
	public void given_WhenConvertingFromUSDtoINR_ThenReturnPass() throws Exception {
		test = report.startTest("USD to INR Conversion");
		response = "{\"id\": 10001,\"from\": \"USD\",\"to\": \"INR\",\"conversionMultiple\": 65.00,\"quantity\": 100,\"totalCalculatedAmount\": 6500.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/USD/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
				//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
	}

	@Test
	@DisplayName("EUR to INR Convertor")
	public void given_WhenConvertingFromEURtoINR_ThenReturn() throws Exception {
		test = report.startTest("EUR to INR Convertor Fail");
		response = "{\"id\": 10002,\"from\": \"EUR\",\"to\": \"INR\",\"conversionMultiple\":84.00,\"quantity\":100,\"totalCalculatedAmount\":8400.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/EUR/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
				//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
	}
	@Test
	@DisplayName("EUR to INR Convertor")
	public void given_WhenConvertingFromEURtoINR_ThenReturnPass() throws Exception {
		test = report.startTest("EUR to INR Conversion");
		response = "{\"id\": 10002,\"from\": \"EUR\",\"to\": \"INR\",\"conversionMultiple\":75.00,\"quantity\":100,\"totalCalculatedAmount\":7500.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/EUR/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
				//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
	}
	@Test
	@DisplayName("AUD to INR Convertor")
	public void given_WhenConvertingFromAUDtoINR_ThenReturn() throws Exception {
		test = report.startTest("AUD to INR Convertor Fail");
		response = "{\"id\":10003,\"from\": \"AUD\",\"to\": \"INR\",\"conversionMultiple\": 51.00,\"quantity\": 100,\"totalCalculatedAmount\":5100.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/AUD/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
				//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
		
				
	}
	@Test
	@DisplayName("AUD to INR Convertor")
	public void given_WhenConvertingFromAUDtoINR_ThenReturnPass() throws Exception {
		test = report.startTest("AUD to INR Conversion");
		response = "{\"id\":10003,\"from\": \"AUD\",\"to\": \"INR\",\"conversionMultiple\": 25.00,\"quantity\": 100,\"totalCalculatedAmount\":2500.00,\"port\":8000}";
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.get("/currency-converter/from/AUD/to/INR/quantity/100")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
				//.andExpect(content().string(response.replaceAll(" ", "")));
		String actualResponse=result.getResponse().getContentAsString();
		validateResponse (actualResponse,response);
	}
*/	private void validateResponse(String actualResponse,String expectedResponse) throws UnsupportedEncodingException {
		test.log(LogStatus.INFO, "Expected Response is ------->   "+expectedResponse);
		test.log(LogStatus.INFO, "Actual Response is ------->   "+actualResponse);
		if(actualResponse.equalsIgnoreCase(expectedResponse.replaceAll(" ", "")))
			test.log(LogStatus.PASS, "Test Passed");
		else
			test.log(LogStatus.FAIL, "Test Failed");
	}

	/*
	 * @Test void contextLoads() { }
	 */
	@AfterClass
	public static void endTest()
	{
	report.endTest(test);
	report.flush();
	}
}

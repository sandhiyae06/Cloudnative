/**
 * 
 */
package com.ContractTesting.ConversionService;

import java.math.BigDecimal;

import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author 616814
 *
 */
@ApiModel(description = "All details about the CurrencyConversionBean")
public class CurrencyConversionBean {

	private Long id;
	
	@Size(min = 3, message = "from should have atleast 3 characters")
	@ApiModelProperty(notes = "from should have atleast 3 characters")
	private String from;
	
	@Size(min = 3, message = "to should have atleast 3 characters")
	@ApiModelProperty(notes = "to should have atleast 3 characters")
	private String to;
	
	@Positive(message = "conversionMultiple should have valid multiplier")
	@ApiModelProperty(notes = "conversionMultiple should have valid multiplier")
	private BigDecimal conversionMultiple;
	
	@Positive(message = "quantity should have only positive multiplier")
	@ApiModelProperty(notes = "quantity should have only positive multiplier")
	private BigDecimal quantity;
	
	@Positive(message = "totalCalculatedAmount from given inputs")
	@ApiModelProperty(notes = "totalCalculatedAmount from given inputs")
	private BigDecimal totalCalculatedAmount;
	
	@Positive(message = "port should not be empty")
	@ApiModelProperty(notes = "port should not be empty")
	private int port;

	public CurrencyConversionBean() {
		
	}
	
	public CurrencyConversionBean(Long id, String from, String to, BigDecimal conversionMultiple, BigDecimal quantity,
			BigDecimal totalCalculatedAmount, int port) {
		super();
		this.id = id;
		this.from = from;
		this.to = to;
		this.conversionMultiple = conversionMultiple;
		this.quantity = quantity;
		this.totalCalculatedAmount = totalCalculatedAmount;
		this.port = port;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public BigDecimal getConversionMultiple() {
		return conversionMultiple;
	}

	public void setConversionMultiple(BigDecimal conversionMultiple) {
		this.conversionMultiple = conversionMultiple;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTotalCalculatedAmount() {
		return totalCalculatedAmount;
	}

	public void setTotalCalculatedAmount(BigDecimal totalCalculatedAmount) {
		this.totalCalculatedAmount = totalCalculatedAmount;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

}
